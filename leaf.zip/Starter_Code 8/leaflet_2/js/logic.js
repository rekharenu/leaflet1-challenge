// Define your Mapbox API key
var api_key = 'your_mapbox_api_key_here'; // Replace with your actual Mapbox API key

// Store our API endpoints
var queryUrl = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson";
var tecplatesUrl = "https://raw.githubusercontent.com/fraxen/tectonicplates/master/GeoJSON/PB2002_boundaries.json";

// GET request for earthquake data
d3.json(queryUrl).then(function(data) {
    console.log(data); // Logging earthquake data to verify
    createFeatures(data.features); // Call createFeatures function to process earthquake data
});

// Function to determine marker color based on earthquake depth
function chooseColor(depth) {
    if (depth < 10) return "#00FF00";
    else if (depth < 30) return "greenyellow";
    else if (depth < 50) return "yellow";
    else if (depth < 70) return "orange";
    else if (depth < 90) return "orangered";
    else return "#FF0000";
}

// Function to create earthquake features on the map
function createFeatures(earthquakeData) {
    // Function to bind popups with detailed information to each earthquake marker
    function onEachFeature(feature, layer) {
        layer.bindPopup(`<h3>Location: ${feature.properties.place}</h3><hr>
            <p>Date: ${new Date(feature.properties.time)}</p>
            <p>Magnitude: ${feature.properties.mag}</p>
            <p>Depth: ${feature.geometry.coordinates[2]}</p>`);
    }

    // Create a GeoJSON layer for earthquakes
    var earthquakes = L.geoJSON(earthquakeData, {
        // Function to customize each point in the GeoJSON layer
        pointToLayer: function(feature, latlng) {
            var markers = {
                radius: feature.properties.mag * 20000, // Set marker size based on magnitude
                fillColor: chooseColor(feature.geometry.coordinates[2]), // Set marker color based on depth
                fillOpacity: 0.7,
                color: "black", // Border color of markers
                weight: 0.5
            };
            return L.circleMarker(latlng, markers); // Create circular markers at earthquake locations
        },
        onEachFeature: onEachFeature // Bind popups to each feature (earthquake)
    });

    createMap(earthquakes); // Call createMap function to initialize the map with earthquake data
}

// Function to create the map with the specified layers and legend
function createMap(earthquakes) {
    // Define base map layers from Mapbox
    var satellite = L.tileLayer('https://api.mapbox.com/styles/v1/{style}/tiles/{z}/{x}/{y}?access_token={access_token}', {
        attribution: "@ <a href='https://www.mapbox.com/about/maps/'>Mapbox</a> @<a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a><strong><a href='https://www.mapbox.com/map-feedback/' target='_blank'>Improve this map</a></strong>",
        tileSize: 512,
        maxZoom: 18,
        zoomOffset: -1,
        style: 'mapbox/satellite-v9',
        access_token: api_key // Use your Mapbox API key here
    });

    var grayscale = L.tileLayer('https://api.mapbox.com/styles/v1/{style}/tiles/{z}/{x}/{y}?access_token={access_token}', {
        attribution: "@ <a href='https://www.mapbox.com/about/maps/'>Mapbox</a> @<a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a><strong><a href='https://www.mapbox.com/map-feedback/' target='_blank'>Improve this map</a></strong>",
        tileSize: 512,
        maxZoom: 18,
        zoomOffset: -1,
        style: 'mapbox/light-v11',
        access_token: api_key // Use your Mapbox API key here
    });

    var outdoors = L.tileLayer('https://api.mapbox.com/styles/v1/{style}/tiles/{z}/{x}/{y}?access_token={access_token}', {
        attribution: "@ <a href='https://www.mapbox.com/about/maps/'>Mapbox</a> @<a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a><strong><a href='https://www.mapbox.com/map-feedback/' target='_blank'>Improve this map</a></strong>",
        tileSize: 512,
        maxZoom: 18,
        zoomOffset: -1,
        style: 'mapbox/outdoors-v12',
        access_token: api_key // Use your Mapbox API key here
    });

    // Layer group for tectonic plates
    var tecPlates = new L.layerGroup();

    // GET request for tectonic plates data
    d3.json(tecplatesUrl).then(function(plates) {
        console.log(plates); // Logging tectonic plates data to verify
        L.geoJSON(plates, {
            color: "orange", // Set color for tectonic plate boundaries
            weight: 2 // Set weight (thickness) of tectonic plate boundaries
        }).addTo(tecPlates); // Add tectonic plates layer to layer group
    });

    // Define base maps and overlay maps
    var baseMaps = {
        "Satellite": satellite,
        "Grayscale": grayscale,
        "Outdoors": outdoors
    };

    var overlayMaps = {
        "Earthquakes": earthquakes,
        "Tectonic Plates": tecPlates
    };

    // Create the map with specified layers and options
    var myMap = L.map("map", {
        center: [37.09, -95.71], // Center map at specified coordinates
        zoom: 5, // Set initial zoom level
        layers: [satellite, earthquakes, tecPlates] // Specify layers to display initially
    });

    // Define a legend control positioned at the bottom-right corner of the map
    var legend = L.control({ position: "bottomright" });

    // Function to add legend to the map
    legend.onAdd = function() {
        var div = L.DomUtil.create("div", "info legend"),
            depth = [-10, 10, 30, 50, 70, 90]; // Define depth ranges

        div.innerHTML += "<h3 style='text-align: center'>Depth</h3>"; // Add legend title

        // Loop through depth ranges and add color squares with labels
        for (var i = 0; i < depth.length; i++) {
            div.innerHTML += '<i style="background:' + chooseColor(depth[i] + 1) + '"></i> ' +
                depth[i] + (depth[i + 1] ? '&ndash;' + depth[i + 1] + '<br>' : '+');
        }

        return div; // Return the legend div element
    };

    legend.addTo(myMap); // Add legend to the map

    // Add layer control to the map to toggle base maps and overlay maps
    L.control.layers(baseMaps, overlayMaps, {
        collapsed: false // Expand layer control by default
    }).addTo(myMap);
}
