// Define your Mapbox API key
var api_key = "pk.eyJ1Ijoicm9zYXpodSIsImEiOiJja2ZvbTFvbzEyM2c1MnVwbTFjdmVycXk5In0.71jVP2vD8pBWO2bsKtI48Q";
// Replace with your actual Mapbox API key

// Store our API endpoint as queryUrl
var queryUrl = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson";

// GET request using D3.js
d3.json(queryUrl).then(function(data) {
    console.log(data); // Logging the earthquake data to console for verification
    createFeatures(data.features); // Call createFeatures function to process the data
});

// Function to determine marker size based on earthquake magnitude
function markerSize(magnitude) {
    return magnitude * 2000; // Adjust multiplier as needed
}

// Function to determine marker color based on earthquake depth
function chooseColor(depth) {
    if (depth < 10) return "#00FF00"; // Green for shallow earthquakes
    else if (depth < 30) return "greenyellow"; // Light green for moderate depth
    else if (depth < 50) return "yellow"; // Yellow for intermediate depth
    else if (depth < 70) return "orange"; // Orange for relatively deep earthquakes
    else if (depth < 90) return "orangered"; // Red-orange for deeper earthquakes
    else return "#FF0000"; // Red for the deepest earthquakes
}

// Function to create earthquake features on the map
function createFeatures(earthquakeData) {
    // Function to bind popups with detailed information to each earthquake marker
    function onEachFeature(feature, layer) {
        layer.bindPopup(`<h3>Location: ${feature.properties.place}</h3><hr>
            <p>Date: ${new Date(feature.properties.time)}</p>
            <p>Magnitude: ${feature.properties.mag}</p>
            <p>Depth: ${feature.geometry.coordinates[2]}</p>`);
    }

    // Create a GeoJSON layer for earthquakes
    var earthquakes = L.geoJSON(earthquakeData, {
        // Function to customize each point in the GeoJSON layer
        pointToLayer: function(feature, latlng) {
            var markers = {
                radius: markerSize(feature.properties.mag), // Set marker size based on magnitude
                fillColor: chooseColor(feature.geometry.coordinates[2]), // Set marker color based on depth
                fillOpacity: 0.7,
                color: "black", // Border color of markers
                stroke: true,
                weight: 0.5
            };
            return L.circle(latlng, markers); // Create circular markers at earthquake locations
        },
        onEachFeature: onEachFeature // Bind popups to each feature (earthquake)
    });

    createMap(earthquakes); // Call createMap function to initialize the map with earthquake data
}

// Function to create the map with the specified layers and legend
function createMap(earthquakes) {
    // Define grayscale map layer from Mapbox
    var grayscale = L.tileLayer('https://api.mapbox.com/styles/v1/{style}/tiles/{z}/{x}/{y}?access_token={access_token}', {
        attribution: "@ <a href='https://www.mapbox.com/about/maps/'>Mapbox</a> @<a href='http://www.openstreetmap.org/copyright'>OpenStreetMap</a><strong><a href='https://www.mapbox.com/map-feedback/' target='_blank'>Improve this map</a></strong>",
        tileSize: 512,
        maxZoom: 18,
        zoomOffset: -1,
        style: 'mapbox/light-v11', // Map style from Mapbox
        access_token: api_key // Use your Mapbox API key here
    });

    // Create the map centered at coordinates and add layers
    var myMap = L.map("map", {
        center: [37.09, -95.71], // Center map at coordinates
        zoom: 5, // Initial zoom level
        layers: [grayscale, earthquakes] // Layers to display initially
    });

    // Define a legend control positioned at the bottom-right corner of the map
    var legend = L.control({ position: "bottomright" });

    // Function to add legend to the map
    legend.onAdd = function() {
        var div = L.DomUtil.create("div", "info legend"),
            depth = [-10, 10, 30, 50, 70, 90]; // Define depth ranges

        div.innerHTML += "<h3 style='text-align: center'>Depth</h3>"; // Legend title

        // Loop through depth ranges and add color squares with labels
        for (var i = 0; i < depth.length; i++) {
            div.innerHTML += '<i style="background:' + chooseColor(depth[i] + 1) + '"></i> ' +
                depth[i] + (depth[i + 1] ? '&ndash;' + depth[i + 1] + '<br>' : '+');
        }

        return div; // Return the legend div element
    };

    legend.addTo(myMap); // Add legend to the map
}
